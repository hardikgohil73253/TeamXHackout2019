<div class="sidebar app-aside" id="sidebar">
	<div class="sidebar-container perfect-scrollbar">
		<nav>
			<!-- start: MAIN NAVIGATION MENU -->
			<div class="navbar-title">
				<span>Main Navigation</span>
			</div>
			<ul class="main-navigation-menu">
				<li>
					<a href="dashboard.php">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-home"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Dashboard </span>
							</div>
						</div>
					</a>
				</li>
				<li>
					<a href="javascript:void(0)">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-user"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Volunteer </span><i class="icon-arrow"></i>
							</div>
						</div>
					</a>
					<ul class="sub-menu">
						<li>
							<a href="volunteer-specilization.php">
								<span class="title"> Volunteer Specialization </span>
							</a>
						</li>
						<li>
							<a href="add-volunteer.php">
								<span class="title"> Add Volunteer</span>
							</a>
						</li>
						<li>
							<a href="manage-volunteers.php">
								<span class="title"> Manage Volunteer </span>
							</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="javascript:void(0)">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-user"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Users </span><i class="icon-arrow"></i>
							</div>
						</div>
					</a>
					<ul class="sub-menu">
						<li>
							<a href="manage-users.php">
								<span class="title"> Manage Users </span>
							</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="help-request-history.php">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-file"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Help Request History </span>
							</div>
						</div>
					</a>
				</li>
				<li>
					<a href="volunteer-log.php">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-list"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Volunteer Session Logs </span>
							</div>
						</div>
					</a>
				</li>
				<li>
					<a href="user-logs.php">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-list"></i>
							</div>
							<div class="item-inner">
								<span class="title"> User Session Logs </span>
							</div>
						</div>
					</a>
				</li>
				<li>
					<a href="show-feedback.php">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-list"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Feedback forms</span>
							</div>
						</div>
					</a>
				</li>
				<li>
					<a href="insert-news.php">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-list"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Insert News</span>
							</div>
						</div>
					</a>
				</li>
				<li>
					<a href="javascript:void(0)">
						<div class="item-content">
							<div class="item-media">
								<i class="ti-user"></i>
							</div>
							<div class="item-inner">
								<span class="title"> Resources </span><i class="icon-arrow"></i>
							</div>
						</div>
					</a>
					<ul class="sub-menu">
						<li>
							<a href="resource-category.php">
								<span class="title"> Resource Category </span>
							</a>
						</li>
						<li>
							<a href="add-resource.php">
								<span class="title"> Add Resource</span>
							</a>
						</li>
						<li>
							<a href="manage-resources.php">
								<span class="title"> Manage Resource </span>
							</a>
						</li>
					</ul>
				</li>
			</ul>
			<!-- end: CORE FEATURES -->
		</nav>
	</div>
</div>